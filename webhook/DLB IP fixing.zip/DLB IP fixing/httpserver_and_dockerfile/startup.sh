#!/bin/bash

while [ "1" == "1" ]
do
  if ! pgrep -x "mutateWebHook" > /dev/null
  then
    /opt/mutator/bin/mutateWebHook
  fi
 sleep 1
done
