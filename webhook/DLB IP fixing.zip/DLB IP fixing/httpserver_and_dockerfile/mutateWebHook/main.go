package main

import (
	"fmt"
	"html"
	"io/ioutil"
	"log"
	"net/http"
	"time"

	m "mutateWebHook/mutate"
)

const k8_sa_path_in_pod string = "/var/run/secrets/kubernetes.io/serviceaccount/namespace"

var namespace string
var prefix string

func GetNamespaceFromPod() (bool, string) {
	content, err := ioutil.ReadFile(k8_sa_path_in_pod)
	if err != nil {
		return false, ""
	}
	namespace := string(content)
	return true, namespace
}

func handleRoot(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "hello %q", html.EscapeString(r.URL.Path))
}

func handleMutate(w http.ResponseWriter, r *http.Request) {
	log.Println("New request received...........")
	// read the body / request
	body, err := ioutil.ReadAll(r.Body)
	defer r.Body.Close()

	if err != nil {
		sendError(err, w)
		return
	}

	// mutate the request
	mutated, err := m.Mutate(body, prefix, true)
	if err != nil {
		sendError(err, w)
		return
	}

	// and write it back
	w.WriteHeader(http.StatusOK)
	if mutated != nil {
		w.Write(mutated)
	}
}

func sendError(err error, w http.ResponseWriter) {
	log.Println(err)
	w.WriteHeader(http.StatusInternalServerError)
	fmt.Fprintf(w, "%s", err)
}

func main() {
	log.Println("Starting server ...")

	err, namespace := GetNamespaceFromPod()
	if !err {
		log.Println("unable to fetch Namespace. exiting...")
		return
	}

	prefix = namespace + "-eir4glb-"

	mux := http.NewServeMux()

	mux.HandleFunc("/", handleRoot)
	mux.HandleFunc("/mutate", handleMutate)

	s := &http.Server{
		Addr:           ":8443",
		Handler:        mux,
		ReadTimeout:    10 * time.Second,
		WriteTimeout:   10 * time.Second,
		MaxHeaderBytes: 1 << 20, // 1048576
	}

	log.Fatal(s.ListenAndServeTLS("/certs/eir4glb-webhook.pem", "/certs/eir4glb-webhook.key"))
}
